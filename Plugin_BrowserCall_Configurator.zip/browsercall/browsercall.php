<?php
/*
Plugin Name: BrowserCall Konfigurator
Description: add the BrowserCall Interface to your page.
Author: Benjamin Wegener <info@tevox.com>
Version: 1.0
Author URI: http://tevox.com/
*/

/*	import plugin class */
	require_once('BrowserCall_Configurator.php');

/*	build plugin */
	$browsercall = new BrowserCall_Configurator();
?>